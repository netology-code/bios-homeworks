//
//  main.swift
//  4.4.2_Control_OOP
//
//  Created by Alex Kolovatov on 13.04.2020.
//  Copyright © 2020 Alex Kolovatov. All rights reserved.
//



class Recipe {
    var eggsPerDish = 0
    
    func prepareEggs() {
        
    }
}

class DinosaurEggRecipe: Recipe {
    
    func findDinosaur() {}
    func stealEggs() {
        eggsPerDish = 1
    }
    
    override func prepareEggs() {
        findDinosaur()
        stealEggs()
    }
}

protocol ScrambledEggs {
    var eggsPerDish: Int { get }
    
    func prepareEggs()
}

class ChickenScrambledEggs: ScrambledEggs {
    
    var eggsPerDish: Int {
        return 2
    }
    
    func prepareEggs() {
        takeEggs()
        smashEggs()
        getFire()
        fry()
    }
    
    private func takeEggs() {}
    func smashEggs() {}
    func getFire() {}
    func fry() {}
}

let recipe = ChickenScrambledEggs()

class Human {
    let name: String
    var company: String
    
    private var playVideoGames = true
    
    init(name: String, company: String) {
        self.name = name
        self.company = company
    }
    
    func meet() {
        print("познакомиться")
    }
}

enum Mood {
    case bad
    case good
    case funny
}

private class Car {
    var color: String = "Red"
}

open class Car2 { // internal is default
    open var model: String = "R8"
}

public class Car3 { // internal is default
    
    public var model: String = "R8"
}

class Women: Human { // internal
    
    private var age: Int = 25
    private var mood: Mood = .good // можем читать и менять в рамках одного класса или структуры
    fileprivate var hairColor: String = "Red" // читать и менять в пределах одного файла
    public var wearGlasses: Bool = true // можем читать из другого модуля
    open var eyesColor: String = "Brown" // можем менять из другого модуля
    
    private(set) var cash: Int = 1000 // открыт для чтения закрыт для записи
    
    internal func tellHerAge() { // читать и менять из любого места внутри модуля
        switch mood {
        case .bad:
            print("Такие вопросы женщине не задают")
        case .funny:
            print("А сколько мне на вид?")
        case .good:
            print("Алкоголь мне уже продают")
        }
    }
    
    func changeMood(_ mood: Mood) {
        if mood == .bad {
            self.mood = mood
        }
    }
    
}

extension Women {
    
    func showMood() {
        print(mood)
    }
}

class Man: Human {
    
    func fishing() {
        print("Уехал на рыбалку")
    }
}


let man1 = Man(name: "Vasya", company: "Apple")
let women1 = Women(name: "Women", company: "Google")

women1.tellHerAge()
print(women1.hairColor)
//women1.cash = 2000


enum ValidColor {
    case spaceGray
    case silver
    case gold
    case unknown
}

class Device {
    
    var currentColor: ValidColor {
        get {
            return color
        }
        set(newColor) {
            if newColor == .unknown {
                print("This color isnt valid \(newColor)")
                return
            }
            print("New color is \(newColor)")
            color = newColor
        }
    }
    
    private var color: ValidColor = .spaceGray
}

let iPhoneXS = Device()

iPhoneXS.currentColor = .gold
print(iPhoneXS.currentColor)
iPhoneXS.currentColor = .unknown


print(iPhoneXS.currentColor) // getter
iPhoneXS.currentColor = .gold // setter



let a = 1
let b = 2
let c = a + b

/// Перегрузка операторов

struct Point {
    var x: Int
    var y: Int
}

func +(_ p1: Point, _ p2: Point) -> Point {
    return Point(x: p1.x + p2.x, y: p1.y + p2.y)
}


var p1 = Point(x: 3, y: 4)
let p2 = Point(x: 1, y: 2)

let p3 = p1 + p2
print(p3)

//func += (p1: inout Point, p2: Point) {
//    p1 = p1 + p2
//}
//
//let p4 = Point(x: 10, y: 12)
//p1 += p4
//print(p1)
//
//
//prefix func --(p: inout Point) {
//    p.x -= 1
//    p.y -= 1
//}
//--p1
//print(p1)
//
//postfix func ++(p: inout Point) {
//    p.x += 1
//    p.y += 1
//}
//
//p1++
//print(p1)
//
//func sum(_ x: Int, _ y : Int) -> Int{
//    return x + y
//}
//func sum(_ x: Int, _ y : Int) -> Double{
//    return 2 * Double(x + y)    // преобразует результат в Double
//}
//
//let a : Int = sum(1, 2)     // 3
//let b : Double = sum(1, 2)  // 6.0
//
//
//class ListNode<T: Comparable> {
//    var data: T
//    var next: ListNode<T>?
//    weak var previus: ListNode<T>?
//
//    init(data: T) {
//        self.data = data
//    }
//
//    static func < (left: ListNode<T>, right: ListNode<T>) -> Bool {
//        return (left.data < right.data)
//    }
//}
//
//let node1 = ListNode(data: 10)
//let node2 = ListNode(data: 20)
//
//print(node1 < node2)
//

/// Перегрузка методов
func sum(_ num1: Int, _ num2: Int) -> Int {
    return num1 + num2
}

func sum(_ num1: Double, _ num2: Double) -> Double {
    return num1 + num2
}

let resulDouble: Double = sum(20, 10)
let resultInt: Int = sum(1, 4)
print(resulDouble)
print(resultInt)

func sum(_ str1: String, _ str2: String) -> String {
    return str1 + str2
}


/// Переопределение

class Animal {
    
    func action() {
        print("Я делаю действие")
    }
    
    func run() {
        print("Убегать")
    }
}

class Cat: Animal {
    
    override func action() {
        print("Царапать")
        super.action()
    }
    
    func newAction() {
        super.action()
        super.run()
    }
}

let cat1 = Cat()
//cat1.action()
cat1.newAction()



/// еще одна реализация полиморфизма
class Person {
    var name: String
    var age: Int

    init(name: String, age: Int) {
        self.name = name
        self.age = age
    }
    
    func display() {
        print("Имя: \(name)  Возраст: \(age)")
    }
}

class Employee: Person {
    
    var company: String
    
    init(name: String, age: Int, company: String) {
        self.company = company
        super.init(name:name, age: age)
    }
    override func display() {
//        print("Имя: \(name)  Возраст: \(age)  Сотрудник компании: \(company)")
        super.display()
        print("Сотрудник компании: \(company)")
    }
}

class Manager : Employee{
    override func display() {
        print("Имя: \(name)  Возраст: \(age)  Менеджер компании: \(company)")
    }
}

let tom: Person = Person(name:"Tom", age: 23)
let bob: Person = Employee(name: "Bob", age: 28, company: "Apple")
let alice: Person = Manager(name: "Alice", age: 31, company: "Microsoft")

tom.display()       // Имя: Tom  Возраст: 23
bob.display()       // Имя: Bob  Возраст: 28  Сотрудник компании: Apple
alice.display()     // Имя: Alice  Возраст: 31  Менеджер компании: Microsoft
