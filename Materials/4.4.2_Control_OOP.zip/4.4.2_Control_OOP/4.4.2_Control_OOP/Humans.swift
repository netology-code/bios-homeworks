//
//  Humans.swift
//  4.4.2_Control_OOP
//
//  Created by Alex Kolovatov on 13.04.2020.
//  Copyright © 2020 Alex Kolovatov. All rights reserved.
//

import Foundation

let women2 = Women(name: "Clair", company: "Amazon")
//women2.changeMood(.funny)
//women2.tellHerAge()
//women2.meet()

