//
//  main.swift
//  4.4_Closures_OMG
//
//  Created by Alex Kolovatov on 21.04.2020.
//  Copyright © 2020 Alex Kolovatov. All rights reserved.
//

import Foundation

let empty = {
    // print("empty closure")
    for i in 0...10 {
        print(i)
    }
}

empty()

func emptyFunc() {
    for i in 0...10 {
        print(i)
    }
}

func calculateRefuelFlight(distance: Double, weight: Double) -> Int {
    let fullDistanceWeight = Int(weight * distance)
    
    return fullDistanceWeight * 120
}

func calculateSomething(distance: Double, weight: Double) -> Int {
    return 400
}

var calculateProperty: (Double, Double) -> Int = calculateRefuelFlight

let result = calculateRefuelFlight(distance: 4.51, weight: 75.11)
 
let result2 = calculateProperty(4.51, 75.11)

calculateProperty = calculateSomething


// $0, $1, $2

let calculateRefuelFlight2: (Double, Double) -> Int = { (num1, num2) in
    return Int(num1 * num2)
}

let shorter: (Double, Double) -> Int = {
    return Int($0 * $1)
}

let shortest: (Double, Double) -> Int = {
    Int($0 + $1)
}



//[Int]().filter { > }
import Cocoa

func displaySun() {}
func save(file: Data) -> () {}
func randomColor() -> NSColor { return .yellow }

var displaySunProperty: () -> Void = displaySun
let saveProperty: (Data) -> () = save
let randomColorProperty: () -> NSColor = randomColor

var displaySunProperty2 = {
    print("something")
}

func perimeter(name: String, closure: (Int, Int) -> Int) {
    

    print("Наша фигура \(name) c периметром ")
}


let squarePerimeter: (Int, Int) -> Int = {
    return $0 * 2 + $1 * 2
}

perimeter(name: "Квадрат", closure: squarePerimeter)


func fetchData(completion: (String) -> Void) {
    var result = 0
    
    for i in 0...100_000 {
        result += i
    }
    
    completion("Операция завершена \(result)")
}


fetchData { (text) in
    print("\(text) за какое-то вермя")
}



func stick(wallpaper: String, sheetsCount count: Int, patternAlignment alignment: Bool) {
    // code
    print(wallpaper)
}

class Worker {
    func doWork(_ work: () -> Void, completion: (Bool) -> Void) {
        work()
        completion(true)
    }
}

class Walls {
    
    func hireInRow(worker: Worker) {
        worker.doWork({
            stick(wallpaper: "Rash", sheetsCount: 3, patternAlignment: true)
            stick(wallpaper: "Type2", sheetsCount: 15, patternAlignment: false)
            stick(wallpaper: "Type3", sheetsCount: 7, patternAlignment: false)
        }) { result in
            if result {
                print("work is done")
            } else {
                print("Work isn't finished yet")
            }
        }
    }
}

let walls = Walls()
let raushan = Worker()


walls.hireInRow(worker: raushan)




func doSomething(number: Int, closure: (Int) -> Void) {
    closure(number * number * number)
}

doSomething(number: 5) { result in
    
    let devideResult = result / 25
    
    switch result {
    case 0...50:
        print("от 0 до 50")
    case 51...125:
        print("от 51...125")
    case let num:
        print(num)
    }
    
    
    if result % 5 == 0 {
        print("число кратно 5")
    }
}


let sorted = [16,756,442,6,23]
    .sorted { $0 < $1 }
    .filter { $0 > 23 }
print(sorted)

let sorted2 = [16,756,442,6,23].sorted { (num1, num2) -> Bool in
    return num1 < num2
}

let transform = [16,756,442,6,23].map { $0 * 2 }

print(transform)

//let transform2 = [16,756,442,6,23].map(<#T##transform: (Int) throws -> T##(Int) throws -> T#>)


enum Step: Int {
    case one = 1, two, three, four
    
    static func log(_ step: Step) {
        print("Шаг \(step.rawValue)")
    }
}


/// non-escaping

func getSum(of array: [Int], completion: ((Int) -> Void)) {
    
    /// Шаг 2
    Step.log(.two)
    var sum = 0
    
    for i in array {
        sum += i
    }
    
    /// Шаг 3
    Step.log(.three)
    completion(sum)
}

func doSomethingWithNonEscapingClosure() {
    /// Шаг 1
    Step.log(.one)
    
    getSum(of: [16,756,442,6,23]) { sum in
        /// Шаг 4, заканчивает вызов
        Step.log(.four)
        print("Сумма равна: \(sum)")
    }

}

doSomethingWithNonEscapingClosure()

/// escaping
///
/// Storage
/// Когда вам нужно сохранить замыкание в хранилище, которое существует в памяти, выполняется прошлый вызов вызывающей функции и возвращает компилятор обратно. (Как ожидание ответа API)

var complitionHandler: ((Int) -> Void)?

class MyClass {
    
    func getAnotherSum(of array:[Int], comletion: @escaping ((Int) -> Void)) {
        /// Шаг 2
        var sum: Int = 0
        
        for value in array {
            sum += value
        }
        /// Шаг 3
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            comletion(sum)
        }
        
        /// Шаг 3
//        complitionHandler = comletion
    }
    
    func doSomething() {
        /// Шаг 1
        getAnotherSum(of: [16,756,442,6,23]) { sum in
            print(sum)
            /// Шаг 4, заканчивает вызов
        }
    }
    
}



let myClass = MyClass()
myClass.doSomething()


var emptyC = { (num: Int, text: String) -> Void in
    print("\(num) \(text)")
}

emptyC(5, "Alex")

emptyC = { (num: Int, text: String) -> Void in
    let result = num + 10
    let fullName = text + " " + "Svistoplyasov"
    print("\(result) \(fullName)")
}

emptyC(5, "Alex")

func someFunc(age: Int, func: (Int, String) -> Void) {
    
    print("\(age)")
    
}

var didClose: (() -> Void)?


private func closeButtonTapped() {
    didClose?()
}


didClose = {
    // do some work
}

let nums = [16,756,442,6,23].map({ (num) -> Int in
    return num * 2
})

print(nums)
