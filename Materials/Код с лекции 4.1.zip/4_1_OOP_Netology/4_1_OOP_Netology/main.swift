//
//  main.swift
//  4_1_OOP_Netology
//
//  Created by Alex Kolovatov on 09.04.2020.
//  Copyright © 2020 Alex Kolovatov. All rights reserved.
//

import Foundation

var population: Int = 100000

class City {
    var population: Int = 1_200_000
    var name: String = "Omsk"
    var hasMetro = false
    var hasStation = true
}

let omsk = City()

let moscow = City()
moscow.population = 25_000_000
moscow.name = "Moscow"
moscow.hasMetro = true

/// Moscow
//population
//name


class NewCity {
    public var population: Int
    open var name: String
    internal let numberOfStreets: Int = 2000
    
    private(set) var hasMetro: Bool // открыт для чтения закрыт для записи
    private let hasNevaRiver = true // закрыт
    
    init(population: Int, name: String, hasMetro: Bool) {
        self.population = population
        self.name = name
        self.hasMetro = hasMetro
    }
    
    private func change() {
        hasMetro = false
    }
}

let stPetersburg = NewCity(population: 12_000_000, name: "St. Petersburg", hasMetro: true)
// stPetersburg.hasMetro = false
 print(stPetersburg.hasMetro)
//stPetersburg.change()

class Animal {
    var numberOfLegs: Int = 4
    var type: String = "Unknown"
    
    func action() {
        print("Unknown action")
    }
}

class Cow {

    var gotMilk = true
    
    func action() {
        print("мууу муууу")
    }
}

class Reptyles: Animal {
    
    var hasShell: Bool = true
    
    override func action() { // перегрузка оператора (метода)
        print("Я ползаю по песочку...")
        super.action()
    }
    
}

let cow = Cow()
let snake = Reptyles()

//[cow, snake].forEach { animal in
//
//    if let mySnake = animal as? Reptyles {
//        print(mySnake.hasShell)
//    }
//
//    if let cow = animal as? Cow {
//        print(cow.gotMilk)
//    }
//}

protocol Displayable {
    func dispayText(_ text: String)
}

class Laptop: Displayable {
    
    func dispayText(_ text: String) {
        print("Мы видим: \(text) на нашем ноуте")
    }
    
}

class RunningStraw: Displayable {
    
    func dispayText(_ text: String) {
        print("Бегущая строка показывает: \(text)")
    }
    
}

class iPhone: Displayable {
    
    func dispayText(_ text: String) {
        print("iPhone XS показывает: \(text)")
    }
}

class MicrowaveOven {
    
    func dispayText(_ text: String) {
        print("микроволновка: \(text)")
    }
}

let laptop: Displayable = Laptop()
let runningStraw: Displayable = RunningStraw()
let iphone: Displayable = iPhone()

let devices: [Displayable] = [laptop, runningStraw, iphone]

for device in devices {
    device.dispayText("Hello, Work!")
}

